# Cycle 008 Planning Package

```text
Cycle 008 — Agent Attack Graph MVP
Base: main with Cycles 001–007
Branch: agent/cycle-008-agent-attack-graph-mvp
Approval: PENDING
```

Core objective:

```text
inventory + authority + evidence + coverage
→ deterministic attack graph
→ attack paths
```

Safety boundary:

```text
analysis and graph derivation
NOT autonomous exploitation
```

`APPROVAL.md` is intentionally absent.
