# Cycle 007 Planning Package

```text
Cycle 007 — MCP Security Benchmark & Corpus Methodology
Base: main with Cycles 001–006
Branch: agent/cycle-007-mcp-security-benchmark-corpus-methodology
Approval: PENDING
```

Core constraints:

```text
pinned revisions
coverage-aware denominators
human validation
responsible disclosure
static/passive by default
no unauthorized third-party dynamic testing
```

`APPROVAL.md` is intentionally absent.
