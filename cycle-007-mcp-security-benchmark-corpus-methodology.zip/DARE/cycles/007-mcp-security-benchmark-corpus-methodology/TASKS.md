# Cycle 007 — Tasks

**Status:** READY FOR REVIEW  
**Approval:** PENDING

## task-001 — Reconcile post-Cycle-006 `main`
Inspect real Cycles 001–006 contracts, schemas, CLI, profiles, coverage semantics, canonicalization and CI.

## task-002 — Define Corpus Manifest schema
Create the versioned corpus-selection and pinned-target contract.

## task-003 — Define Benchmark Run schema
Freeze corpus, engine, profile, registry, policies, runner and environment identity.

## task-004 — Define Benchmark Record schema
Create normalized target/run output reusing existing evidence and coverage contracts.

## task-005 — Implement corpus dedup and lineage classification
Prevent mirrors/forks/examples from inflating prevalence.

## task-006 — Define sampling and corpus-selection methodology
Document population, inclusion/exclusion, stratification and representativeness limits.

## task-007 — Define benchmark eligibility and aggregation math
Implement coverage-aware property denominators and confidence/error handling.

## task-008 — Implement safe benchmark runner
Thin runner with pinned revisions, isolation, restricted network and static/local-passive defaults.

## task-009 — Build benchmark security fixtures
Test hostile repository/manifests and runner safety boundaries.

## task-010 — Implement human-validation ledger
Support positive, negative and ambiguous validation samples.

## task-011 — Define responsible-disclosure workflow
Define publication, embargo, redaction and coordinated-disclosure states.

## task-012 — Build pilot corpus
Create a 25–50 target public OSS methodology-validation corpus.

## task-013 — Produce aggregate benchmark output
Generate coverage, property failure, severity/confidence and blind-spot statistics.

## task-014 — Add CI regression coverage
Test schemas, eligibility, canonicalization, dedup and runner safety using deterministic fixtures.

## task-015 — Write methodology and interpretation documentation
Document formulas, limitations, reproducibility, validation and disclosure.

## task-016 — Final DARE proof
Map every acceptance criterion to deterministic implementation/test evidence.
